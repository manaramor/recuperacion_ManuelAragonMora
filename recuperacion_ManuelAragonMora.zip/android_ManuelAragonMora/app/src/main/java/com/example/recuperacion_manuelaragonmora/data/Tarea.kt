package com.example.contratartareas.data

data class Tarea(val nombre:String, val precio:Int, var cantidadHoras: Int)