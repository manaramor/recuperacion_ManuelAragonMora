package com.example.contratartareas.data

object DataSource{
val tareas = arrayListOf<Tarea>(
    Tarea("Bricolaje", 6,0),
    Tarea("Limpieza baño", 12,0),
	Tarea("Limpieza casa", 7,0),
    Tarea("Pequeñas reparaciones", 12,0),
    Tarea("Redacción", 9,0),
    )
}