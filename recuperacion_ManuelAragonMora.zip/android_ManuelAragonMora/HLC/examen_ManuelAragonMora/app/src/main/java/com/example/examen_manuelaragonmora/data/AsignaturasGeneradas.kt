package com.example.examen_manuelaragonmora.data

object DataSource {
    val loterias = arrayListOf<Asignatura>(
        Asignatura("Historia", 8),
        Asignatura("Lengua", 9),
        Asignatura("Inglés", 12),
        Asignatura("Sociales", 12),
        Asignatura("Biología", 10),
        Asignatura("Física", 9),
        Asignatura("Química", 9),

        )
}