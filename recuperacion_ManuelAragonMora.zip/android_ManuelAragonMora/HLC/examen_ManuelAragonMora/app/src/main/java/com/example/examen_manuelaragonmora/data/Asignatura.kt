package com.example.examen_manuelaragonmora.data

data class Asignatura (var nombre:String, val precioHora:Int)