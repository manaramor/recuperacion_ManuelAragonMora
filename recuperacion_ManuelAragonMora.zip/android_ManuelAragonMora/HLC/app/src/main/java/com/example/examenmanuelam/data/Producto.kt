package com.example.examenmanuelam.data

data class Producto (val nombre: String, val precio: Int)